select * from Stock

delete from LoginInfo
